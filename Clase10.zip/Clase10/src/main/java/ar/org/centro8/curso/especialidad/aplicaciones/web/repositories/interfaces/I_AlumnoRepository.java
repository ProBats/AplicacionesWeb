package ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.interfaces;

import java.util.List;

import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Alumno;

public interface I_AlumnoRepository {
	
	void save(Alumno alumno);
	
	void remove(Alumno alumno);
	
	void restore(Alumno alumno);
	
	void update(Alumno alumno);
	 
	List<Alumno>getAllAsset();
	
	
	default Alumno getByIdAsset(int id) {
		return getAllAsset()
						.stream()
						.filter(alumno->alumno.getId()==id)
						.findFirst()
						.orElse(new Alumno());
	}
	
	default List<Alumno>getLikeNombreAsset(String nombre){
		return getAllAsset()
						.stream()
						.filter(alumno->
					                 alumno
					                 		.getNombre()
					                 		.toLowerCase()
					                 		.contains(nombre.toLowerCase()))
						.toList();
	}
	
	List<Alumno>getAllPasive();
	
	default Alumno getByIdPasive(int id) {
		return getAllPasive()
						.stream()
						.filter(alumno->alumno.getId()==id)
						.findFirst()
						.orElse(new Alumno());
	}
	
	default List<Alumno>getLikeNombrePasive(String nombre){
		return getAllPasive()
						.stream()
						.filter(alumno->
					                 alumno
					                 		.getNombre()
					                 		.toLowerCase()
					                 		.contains(nombre.toLowerCase()))
						.toList();
	}
	
	
}
