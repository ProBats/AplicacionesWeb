-- Inserts para la tabla cursos
INSERT INTO cursos (titulo, profesor, dia, turno) VALUES 
('Matemáticas Básicas', 'Profesor A', 'LUNES', 'MAÑANA'),
('Historia del Arte', 'Profesor B', 'MARTES', 'TARDE'),
('Programación en Python', 'Profesor C', 'MIERCOLES', 'NOCHE'),
('Literatura Universal', 'Profesor D', 'JUEVES', 'MAÑANA'),
('Física Aplicada', 'Profesor E', 'VIERNES', 'TARDE'),
('Inglés Avanzado', 'Profesor F', 'LUNES', 'TARDE'),
('Economía Básica', 'Profesor G', 'MARTES', 'NOCHE'),
('Diseño Gráfico', 'Profesor H', 'MIERCOLES', 'MAÑANA'),
('Marketing Digital', 'Profesor I', 'JUEVES', 'TARDE'),
('Psicología General', 'Profesor J', 'VIERNES', 'NOCHE');

-- Inserts para la tabla alumnos
INSERT INTO alumnos (nombre, apellido, edad, idCurso) VALUES 
('Juan', 'Gómez', 20, 1),
('María', 'Martínez', 25, 2),
('Carlos', 'López', 22, 3),
('Laura', 'García', 19, 4),
('Pedro', 'Sánchez', 21, 5),
('Sofía', 'Díaz', 24, 6),
('Ana', 'Rodríguez', 23, 7),
('Luis', 'Pérez', 30, 8),
('Elena', 'Hernández', 28, 9),
('Javier', 'Fernández', 26, 10);
