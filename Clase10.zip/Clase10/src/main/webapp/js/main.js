function confirmarEliminacion(){
	return window.confirm("¿Estás seguro de que deseas eliminar?")
}

function confirmarRestauracion(){
	return window.confirm("¿Estás seguro de que deseas restaurar es información?")
}