package ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.interfaces;

import java.util.List;

import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Alumno;

public interface I_AlumnoRepository {
	
	void save(Alumno alumno);
	
	void remove(Alumno alumno);
	
	void update(Alumno alumno);
	 
	List<Alumno>getAll();
	
	default Alumno getById(int id) {
		return getAll()
						.stream()
						.filter(alumno->alumno.getId()==id)
						.findFirst()
						.orElse(new Alumno());
	}
	
	default List<Alumno>getLikeNombre(String nombre){
		return getAll()
						.stream()
						.filter(alumno->
					                 alumno
					                 		.getNombre()
					                 		.toLowerCase()
					                 		.contains(nombre.toLowerCase()))
						.toList();
	}
}
