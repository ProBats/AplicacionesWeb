package ar.org.centro8.curso.especialidad.aplicaciones.web.test;

import ar.org.centro8.curso.especialidad.aplicaciones.web.entities.Alumno;
import ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.especialidad.aplicaciones.web.repositories.jdbc.AlumnoRepository;

public class TestAlumnoRepository {
    public static void main(String[] args) {
        I_AlumnoRepository cr=new AlumnoRepository();

        //System.out.println("-- .save() --");
        //Alumno alumno=new Alumno("Elvis", "Morales", 23, 4);
        //cr.save(alumno);
        //System.out.println(alumno);
        
        //System.out.println("-- .remove() --");
        //cr.remove(cr.getById(5));
        //cr.remove(cr.getById(6));
        System.out.println("-- .getAll() --");
        cr.getAll().forEach(System.out::println);
    }
}
